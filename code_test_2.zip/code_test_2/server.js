const express = require('express');
const bodyParser = require('body-parser');

const app = express();

const fs = require('fs');
const port = '8082';

app.use(bodyParser.json()); //for handling json data
app.use(bodyParser.urlencoded({extended:true}));

const routes = require('./routes/router.js')(app, fs); //for handling various routes

//launching server at port 8082
app.listen(port,()=>{
    console.log("server is listening to port " + port);
});


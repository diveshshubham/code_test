const appRouter = (app, fs) => {


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to get default message ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    app.get('/', (req, res) => {
        res.send({ message: "want something exciting!!!!" }) //default message
    });

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to get all the offers (point 7 of acceptance citeria) ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    app.get('/allOffers', (req, res) => {
        let finalData = [];
        var offers = JSON.parse(fs.readFileSync('pointers_dynamodb.export.json', 'utf8'));//importing and reading json file

        for (var i = 0; i < offers.Items.length; i++) 
            {
                const details = 
                {
                    id: offers.Items[i].id,
                    portfolio : offers.Items[i].portfolio,
                    available : offers.Items[i].available,
                    condition:offers.Items[i].conditions,
                    visible : offers.Items[i].visible,
                    car : offers.Items[i].car,
                    labels: offers.Items[i].labels,
                    segment : offers.Items[i].segment,
                    images : offers.Items[i].images,
                    pricing: offers.Items[i].pricing,
                    estimatedDelivery : offers.Items[i].estimatedDeliveryTime
                }

                finalData.push(details); //pushing required details in finalData
            }
        res.send(finalData);
        console.log(finalData);
    });



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to get all visible offers (point 1,2,3 and 6 of acceptance citeria) ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    app.get('/visibleOffers', (req, res) => {
        const numberOfOffers = parseInt(req.query.numberOfOffers); //reading query for limiting number of offers
        var lengthOfOffers = '';
        let finalData = [];
        let limitedData = [];
        var offers = JSON.parse(fs.readFileSync('pointers_dynamodb.export.json', 'utf8'));//importing and reading json file

        if (!numberOfOffers) 
        {
            lengthOfOffers = offers.Items.length; //it will give existing length of an Items object in json file
        }
        else 
        {
            lengthOfOffers = numberOfOffers; //it will fetch number from query and list offers as per the requested query
        }
        //console.log(lengthOfOffers);
        for (var i = 0; i < offers.Items.length; i++) 
        {
            if (offers.Items[i].visible.BOOL == true)  //checking visiblity of offers
            { //console.log(offers.Items[i].visible);
                const details = 
                {
                    id: offers.Items[i].id,
                    teaser: offers.Items[i].teaser,
                    detailUrl: offers.Items[i].detailUrl,
                    labels: offers.Items[i].labels,
                    price: offers.Items[i].pricing
                }

                finalData.push(details);//sending only visible offers to a finaldata array
                //console.log(finalData);
            }
        }
        for(var j=0 ; j<lengthOfOffers;j++)
            {
                limitedData.push(finalData[j]); //making an array of requested number of offers
            }
        res.send(limitedData);
        console.log(limitedData);
    });



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to get all the offers searched by portfolio (point 4 - a of acceptance citeria) ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    app.get('/offers/searchByPorfolio', (req, res) => {
        const portfolioToBeSearched = req.query.portfolio;
        let finalData = [];
        let setPortfolio = '';
        if (!portfolioToBeSearched) 
        {
            setPortfolio = '0001'; //setting default portfolio "0001"
        } 
        else 
        {
            setPortfolio = req.query.portfolio; //fetching portfolio valuse to be searched
        }

        var offers = JSON.parse(fs.readFileSync('pointers_dynamodb.export.json', 'utf8')); //importing and reading json file
        for (var i = 0; i < offers.Items.length; i++) 
        {   
            if ((offers.Items[i].visible.BOOL == true) && (offers.Items[i].portfolio.S == setPortfolio))//checking the condition and searching for the requested query
            { console.log(offers.Items[i].portfolio.S);
                const details = 
                {
                    id: offers.Items[i].id,
                    teaser: offers.Items[i].teaser,
                    detailUrl: offers.Items[i].detailUrl,
                    labels: offers.Items[i].labels,
                    price: offers.Items[i].pricing
                }

                finalData.push(details);
                //console.log(finalData);
            }
        }
        res.send(finalData);
    });



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to get all the offers searched by or or multiple makes  (point 4-b of acceptance citeria) ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    app.get('/offers/searchByMake', (req, res) => {
        const makeToBeSearched = req.query.make;
        const str = makeToBeSearched.split(','); //getting an array of makes to be searched 
        let finalData = [];

        var offers = JSON.parse(fs.readFileSync('pointers_dynamodb.export.json', 'utf8'));

        for (var j = 0; j < str.length; j++) //putting arrays of makes in for loop 
        {
            for (var i = 0; i < offers.Items.length; i++) 
            {   
                if ((offers.Items[i].visible.BOOL == true) && (offers.Items[i].car.M.make.S == str[j])) //searching makes for visible offers
                {   console.log(offers.Items[i].car.M.make.S);
                    const details = 
                    {
                        id: offers.Items[i].id,
                        teaser: offers.Items[i].teaser,
                        detailUrl: offers.Items[i].detailUrl,
                        labels: offers.Items[i].labels,
                        price: offers.Items[i].pricing
                    }

                    finalData.push(details);
                    //console.log(finalData);
                }
            }
        }
        res.status(200).send(finalData);
    });



    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to get all the offers searched within a price's range(point 4-c of acceptance citeria) ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    app.get('/offers/searchByRange', (req, res) => {
        const rangeToBeSearched = req.query.range;
        const str = rangeToBeSearched.split('-'); //getting an price ranges
        let finalData = [];

        var offers = JSON.parse(fs.readFileSync('pointers_dynamodb.export.json', 'utf8'));

        for (var i = 0; i < offers.Items.length; i++) 
        {
            if ((offers.Items[i].visible.BOOL == true) && (offers.Items[i].pricing.M.price.N < parseInt(str[1]))&& 
            (offers.Items[i].pricing.M.price.N > parseInt(str[0]))) //searching offers in a requested range of price
            {   console.log(offers.Items[i].pricing.M.price.N);
                const details = 
                {
                    id: offers.Items[i].id,
                    detailUrl: offers.Items[i].detailUrl,
                    visible: offers.Items[i].visible,
                    teaser: offers.Items[i].teaser,
                    labels: offers.Items[i].labels,
                    price: offers.Items[i].pricing
                }

                finalData.push(details);
                //console.log(finalData);
            }
        }

        res.status(200).send(finalData);
    });


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////// endpoint to sort the offers by ascending order of price(point 5 of acceptance citeria) ///////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    app.get('/offers/ascending', (req, res) => {

        const offers = JSON.parse(fs.readFileSync('pointers_dynamodb.export.json', 'utf8'));

        let finalData = [];
        for (var i = 0; i < offers.Items.length; i++) 
        {
            if (offers.Items[i].visible.BOOL == true) 
            {
                const details = 
                {
                    id: offers.Items[i].id,
                    detailUrl: offers.Items[i].detailUrl,
                    visible: offers.Items[i].visible,
                    teaser: offers.Items[i].teaser,
                    labels: offers.Items[i].labels,
                    price : parseInt(offers.Items[i].pricing.M.price.N)
                }

                finalData.push(details);
            }
        }

        function sortByProperty(property)  //function for sorting an array in ascending order
        {
            return function (a, b) {
                if (a[property] > b[property])
                    return 1;
                else if (a[property] < b[property])
                    return -1;

                return 0;
            }
        }

        finalData.sort(sortByProperty("price"));   //sorting required data into ascedning order by price   
        res.send(finalData);
        console.log(finalData);
    });
};
module.exports = appRouter;
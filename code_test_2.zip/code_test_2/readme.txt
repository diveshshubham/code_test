step -1 : open rot directory of project and open terminal in that directory
step -2 : enter command - npm install
step -3 : after installing enter command - node server.js    
    
    
    1. The list of offers only returns “visible” offers - 
    => endpoint : http://localhost:8082/visibleOffers
        output : it will only return visible offers with their id,teaser,detailedUrl,labels and price


    2. The list of offers contains the number of returned offers and the following information:
        a. Id
        b. Complete teaser information
        c. detailUrl (a link to the webpage)
        d. Labels
        e. Price
    => endpoint : http://localhost:8082/visibleOffers


    3. The list of offers can be limited to a number (e.g. return only 10 offers)
    => endpoint : http://localhost:8082/visibleOffers?numberOfOffers=8  // you can try anyother number than 8 for eg http://localhost:8082/visibleOffers?numberOfOffers=10
                
    4. The list of offers can be filtered by-
        a. Portfolio (only one; the default portfolio should be “0001”)
        => enpoint: http://localhost:8082/offers/searchByPorfolio 
            output : here by default it will show details of portfolio "0001"
        
        endpoint: http://localhost:8082/offers/searchByPorfolio?portfolio=1000  //you can try any other portfolio number also
            output : you can see details of searched portfolio

        b. Make (one or more makes, e.g. BMW, Opel)
        => endpoint: http://localhost:8082/offers/searchByMake?make=Opel,Ford,BMW //you can try as many make as you want to search
            output : details of searched offers by make 

        c. Price ( from/to, e.g. from 350€ to 450€)
        => endpoint : http://localhost:8082/offers/searchByRange?range=200-500 
            try anything like  http://localhost:8082/offers/searchByRange?range=1876-5089  you will be getting desired output
            output : details in a given price range

    5. The list of offers is ordered ascending by price.
    => endpoint : http://localhost:8082/offers/ascending
        output: detials sorted by ascending order of price

    6. The detailed offer information is only returned for “visible” offers.
    => endpoint :http://localhost:8082/visibleOffers
        output: responds with only visible offers

    7. The detailed offer information contains all offer information except teaser and detailUrl
    => endpoint ; http://localhost:8082/allOffers
        output : responds detailed offer information contains all offer information except teaser and detailUrl

    ********************************************************************************************************************************8
    **********************************************************************************************************************************

    you can also see my screen recording here : https://drive.google.com/file/d/1eJYeC9KYEzHOl3JG3kon6bklQkwxrIji/view?usp=sharing

    ********************************************************************************************************************************8
    **********************************************************************************************************************************
